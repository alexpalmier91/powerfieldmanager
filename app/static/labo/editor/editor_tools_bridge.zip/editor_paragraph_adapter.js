/* app/static/labo/editor/editor_paragraph_adapter.js
   Adapter ParagraphTools (paragraph_tools.js) <-> EditorApp sandbox UI
   - dblclick = edit
   - drag = via hit-layer hors édition (para-hit)
*/
(function (global) {
  "use strict";

  const EditorApp = (global.EditorApp = global.EditorApp || {});
  const state = EditorApp.state || (EditorApp.state = {});
  const A = EditorApp.actions;

  const LOG = true;
  const log = (...a) => { if (LOG) console.log("[para_adapter]", ...a); };

  if (!global.ParagraphTools || typeof global.ParagraphTools.createController !== "function") {
    console.warn("[para_adapter] ParagraphTools.createController introuvable (paragraph_tools.js non chargé ?)");
    return;
  }

  const R = {
    mounted: false,
    ctrl: null,
    overlayBound: null,
    overlayKey: null,
    pageIndex: 0,
    routingInstalled: false
  };

  const DRAG_THRESHOLD_PX = 5;

  function getActivePageIndex() {
    const id = state.activePageId;
    if (!id) return 0;
    const idx = (state.pages || []).findIndex(p => p && p.id === id);
    return Math.max(0, idx);
  }

  function getOverlayEl() {
    return (EditorApp.refs && EditorApp.refs.overlayEl) || null;
  }

  function getFontsForTextTools() {
    let fonts = state.fonts;
    if (!Array.isArray(fonts) || fonts.length === 0) fonts = global.EDITOR_FONTS;

    if (!Array.isArray(fonts) || fonts.length === 0) {
      fonts = [{ name: "helv", label: "Helvetica (défaut)", scope: "default", isDefault: true }];
    }

    const out = fonts.map((f) => {
      if (typeof f === "string") return { name: f, label: f, scope: "global", isDefault: false };
      const name = String(f.name || f.value || f.family || "").trim();
      const label = String(f.label || f.name || f.value || name || "Font").trim();
      return {
        name: name || "helv",
        label,
        scope: String(f.scope || "global").toLowerCase(),
        isDefault: !!f.isDefault,
        href: f.href || f.css || f.cssUrl || null,
        url: f.url || null,
        format: f.format || null,
        weight: f.weight || null,
        style: f.style || null,
      };
    }).filter(x => x && x.name);

    state.fonts = out;
    return out;
  }

  // ---------------------------------------------------------------------------
  // CSS (hit-layer + édition) — IMPORTANT: pointer-events gérés ici
  // ---------------------------------------------------------------------------
  function ensureParagraphCssOnce() {
    if (document.getElementById("zh_para_css_v3")) return;
    const st = document.createElement("style");
    st.id = "zh_para_css_v3";
    st.textContent = `
.anno-object[data-type="text_paragraph"]{
  position:absolute;
  box-sizing:border-box;
  touch-action:none;
}

/* texte */
.anno-object[data-type="text_paragraph"] [data-role="richtext"]{
  position:absolute; inset:0;
  outline:none;
  z-index:2;
  pointer-events:auto;
}

/* hit layer au-dessus pour drag (hors édition) */
.anno-object[data-type="text_paragraph"] .para-hit{
  position:absolute; inset:0;
  z-index:3;
  cursor:move;
  pointer-events:auto;
}

/* hors édition: le texte ne capte rien (on drague via para-hit) */
.anno-object[data-type="text_paragraph"]:not(.is-editing) [data-role="richtext"]{
  pointer-events:none;
  user-select:none;
  -webkit-user-select:none;
  cursor:inherit;
}

/* en édition: on coupe le hit-layer => texte cliquable/sélectionnable */
.anno-object[data-type="text_paragraph"].is-editing .para-hit{
  pointer-events:none;
}

.anno-object[data-type="text_paragraph"].is-editing [data-role="richtext"]{
  pointer-events:auto;
  user-select:text !important;
  -webkit-user-select:text !important;
  cursor:text;
  background:transparent !important;
}

.anno-object[data-type="text_paragraph"].is-editing [data-role="richtext"]::selection{
  background: rgba(37,99,235,.35);
}
`;
    document.head.appendChild(st);
  }

  function ensureParagraphHitLayer(blockEl) {
    if (!blockEl) return;
    if (blockEl.querySelector(".para-hit")) return;
    const hit = document.createElement("div");
    hit.className = "para-hit";
    hit.setAttribute("data-role", "para-hit");
    blockEl.prepend(hit);
  }

  function ensureAllParagraphHitLayers() {
    const overlayEl = getOverlayEl();
    if (!overlayEl) return;
    overlayEl.querySelectorAll('[data-type="text_paragraph"]').forEach(ensureParagraphHitLayer);
  }

  function getParagraphBlockElById(objectId) {
    if (!objectId) return null;
    try {
      const el = EditorApp.refs?.objEls?.get?.(String(objectId));
      if (el) return el;
    } catch (_) {}

    const oe = getOverlayEl();
    if (!oe) return null;
    try {
      return oe.querySelector(`[data-type="text_paragraph"][data-objid="${CSS.escape(String(objectId))}"]`);
    } catch (_) {
      return null;
    }
  }

  function setParagraphEditingVisual(blockEl, isEditing) {
    if (!blockEl) return;
    blockEl.classList.toggle("is-editing", !!isEditing);

    const rich = blockEl.querySelector('[data-role="richtext"]');
    if (rich) {
      rich.style.pointerEvents = "";
      rich.style.userSelect = "";
      rich.style.webkitUserSelect = "";
      rich.style.cursor = "";
      rich.style.background = "";
    }
  }

  // ---------------------------------------------------------------------------
  // Controller
  // ---------------------------------------------------------------------------
  function ensureController() {
  const overlayEl = getOverlayEl();
  if (!overlayEl) return null;

  const pageIndex = getActivePageIndex();

  const overlayKey =
    overlayEl.id ||
    overlayEl.getAttribute("data-overlay-id") ||
    overlayEl.dataset?.overlayId ||
    "overlay";

  // ✅ robust: si l’overlay DOM a été remplacé/re-render => on recrée le ctrl
  const overlayStillConnected = !!overlayEl.isConnected;
  const overlayElChanged = (R.overlayBound !== overlayEl);
  const overlayKeyChanged = (R.overlayKey !== overlayKey);
  const pageChanged = (R.pageIndex !== pageIndex);
  const needRecreate = (!R.ctrl) || overlayElChanged || overlayKeyChanged || !overlayStillConnected || pageChanged;

  ensureParagraphCssOnce();

  if (needRecreate) {
    // 🔥 IMPORTANT: on ferme proprement l’ancien controller (s’il existait)
    try { R.ctrl && R.ctrl.exit && R.ctrl.exit(true); } catch (_) {}

    const fonts = getFontsForTextTools();

    // ✅ hostRect = canvasWrap (zone 3) pour placer la toolbar sous/au-dessus correctement
    const getHostRect = () => {
      const wrap = document.getElementById("canvasWrap");
      return wrap ? wrap.getBoundingClientRect() : null;
    };

    R.ctrl = global.ParagraphTools.createController({
      overlayEl,
      getHostRect, // ✅ NEW

      getObject: (pi, objectId) => {
        const page = state.pages?.[pi];
        if (!page || !Array.isArray(page.objects)) return null;
        return page.objects.find(o => String(o.id) === String(objectId)) || null;
      },

      setEditingState: (isEditing, objectId) => {
        state.isEditingText = !!isEditing;
        state.editingObjectId = objectId || null;

        // ⚠️ en sortie d’édition, objectId est null -> on retire la classe du dernier bloc
        if (!objectId) {
          if (state._lastEditingParagraphId) {
            const last = getParagraphBlockElById(state._lastEditingParagraphId);
            if (last) last.classList.remove("is-editing");
          }
          state._lastEditingParagraphId = null;
          try { window.getSelection?.()?.removeAllRanges?.(); } catch (_) {}
          return;
        }

        state._lastEditingParagraphId = String(objectId);

        const blockEl = getParagraphBlockElById(objectId);
        if (!blockEl) return;

        blockEl.classList.toggle("is-editing", !!isEditing);

        if (!isEditing) {
          try { window.getSelection?.()?.removeAllRanges?.(); } catch (_) {}
        }
      },

      onDirty: () => {
        state.dirty = true;
        try { EditorApp.render?.renderOptionsPanel?.(); } catch (_) {}
      },

      getFonts: () => fonts
    });

    // ✅ update bindings UNIQUEMENT après création
    R.overlayBound = overlayEl;
    R.overlayKey = overlayKey;
    R.pageIndex = pageIndex;

    global.__PARA_CTRL__ = R.ctrl;
    log("controller mounted ✅", R.ctrl);
  } else {
    // ✅ keep bindings à jour même si pas de recreate
    R.overlayBound = overlayEl;
    R.overlayKey = overlayKey;
    R.pageIndex = pageIndex;
  }

  installRoutingOnce();
  return R.ctrl;
}


  EditorApp.ensureParagraphController = ensureController;

  function mountOnAfterCanvasRender() {
    if (R.mounted) return;
    R.mounted = true;

    EditorApp.hooks = EditorApp.hooks || {};
    EditorApp.hooks.afterCanvasRender = EditorApp.hooks.afterCanvasRender || [];

    EditorApp.hooks.afterCanvasRender.push(() => {
      ensureParagraphCssOnce();
      ensureAllParagraphHitLayers();

      const ctrl = ensureController();
      if (!ctrl) return;
      try { ctrl.onMoveOrResize && ctrl.onMoveOrResize(); } catch (_) {}
    });
  }


// ---------------------------------------------------------------------------
// Insert (utilisé par editor_tools_bridge.js)
// ---------------------------------------------------------------------------
function fallbackMakeParagraphObject(partial) {
  const p = partial || {};
  const id = p.id || `para_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
  return {
    id,
    type: "text",
    mode: "paragraph",
    x: p.x ?? 120,
    y: p.y ?? 170,
    w: p.w ?? 360,
    h: p.h ?? 140,
    rotation: p.rotation ?? 0,
    opacity: p.opacity ?? 1,
    text: p.text ?? "Paragraphe",
    html: p.html ?? "",
    color: p.color ?? "#111827",
    align: p.align ?? "left",
    font: Object.assign(
      { family: "helv", size: 14, weight: 400, style: "normal", underline: false, transform: "none" },
      p.font || {}
    ),
    lineHeight: p.lineHeight ?? null,
  };
}

function insertParagraph(partial) {
  if (!Array.isArray(state.pages) || !state.pages.length) return null;

  const pageIndex = getActivePageIndex();
  const page = state.pages[pageIndex];
  page.objects = page.objects || [];

  const obj = fallbackMakeParagraphObject(partial);
  page.objects.push(obj);

  state.dirty = true;

  // render
  if (EditorApp.requestRender) EditorApp.requestRender();
  else if (EditorApp.render?.renderAll) EditorApp.render.renderAll();

  log("insertParagraph ✅", obj);
  return obj;
}

// ✅ IMPORTANT : exposé pour tools_bridge
EditorApp.insertParagraph = insertParagraph;


  // ---------------------------------------------------------------------------
  // Toolbar helpers — IMPORTANT: PAS d'enter/exit ici
  // ---------------------------------------------------------------------------
function notifyParagraphSelected(ctrl, pageIndex, objId, blockEl) {
  if (!ctrl || !objId) return;

  if (typeof ctrl.setActive === "function") {
    ctrl.setActive(pageIndex, objId, blockEl);
  } else {
    // fallback ancien: au pire, juste toolbar (mais ton build n’a pas de contexte)
    try { ctrl.ensureToolbar && ctrl.ensureToolbar(); } catch (_) {}
    try { ctrl.onMoveOrResize && ctrl.onMoveOrResize(); } catch (_) {}
  }
}



  // ---------------------------------------------------------------------------
  // Routing
  // ---------------------------------------------------------------------------
  function findParagraphBlockFromEventTarget(t) {
    if (!t || !t.closest) return null;
    return t.closest('[data-type="text_paragraph"]');
  }

  function isInsideRichtext(t) {
    if (!t || !t.closest) return false;
    return !!t.closest('[data-role="richtext"]');
  }

  function isOnHitLayer(t) {
    if (!t || !t.closest) return false;
    return !!t.closest('.para-hit');
  }

  function getIdsFromBlock(blockEl) {
    const pageIndex = Number(blockEl.getAttribute("data-pageindex") || "0") || 0;
    const objId =
      blockEl.getAttribute("data-objid") ||
      blockEl.getAttribute("data-obj-id") ||
      blockEl.dataset.objid ||
      blockEl.dataset.objId;

    return { pageIndex, objId: String(objId || "") };
  }

  let pending = null;
  let drag = null;
  let raf = 0;

  function scheduleDragUpdate(ctrl) {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      if (!drag) return;

      const z = Number(state.zoom || 1) || 1;
      const dx = (drag.lastX - drag.startX) / z;
      const dy = (drag.lastY - drag.startY) / z;

      const nx = drag.ox + dx;
      const ny = drag.oy + dy;

      drag.nx = nx;
      drag.ny = ny;

      if (drag.objRef) { drag.objRef.x = nx; drag.objRef.y = ny; }
      if (drag.blockEl) { drag.blockEl.style.left = nx + "px"; drag.blockEl.style.top = ny + "px"; }

      try { EditorApp.render?.renderTransformsOnly?.(); } catch (_) {}
      try { ctrl?.onMoveOrResize?.(); } catch (_) {}
	  // ✅ certains navigateurs cachent la toolbar pendant pointer-capture => on ré-affiche
try { ctrl?.setActive?.(drag.pageIndex, drag.objId, drag.blockEl); } catch (_) {}

	  
    });
  }

  function beginDragFromPending(e, ctrl) {
    if (!pending) return;

    drag = {
      pageIndex: pending.pageIndex,
      objId: pending.objId,
      blockEl: pending.blockEl,
      pid: pending.pid,
      startX: pending.startX,
      startY: pending.startY,
      lastX: pending.lastX,
      lastY: pending.lastY,
      ox: pending.ox,
      oy: pending.oy,
      nx: pending.ox,
      ny: pending.oy,
      objRef: pending.objRef
    };

    pending = null;

    try { window.getSelection?.()?.removeAllRanges?.(); } catch (_) {}
    try { document.activeElement?.blur?.(); } catch (_) {}

    // ✅ capture UNIQUEMENT quand le drag démarre
    try { drag.blockEl && drag.blockEl.setPointerCapture(drag.pid); } catch (_) {}
	
	// ✅ garder toolbar visible pendant drag (TextToolbarTools peut se cacher)
try { ctrl?.setActive?.(drag.pageIndex, drag.objId, drag.blockEl); } catch (_) {}
try { ctrl?.onMoveOrResize?.(); } catch (_) {}


    e.preventDefault();
    e.stopPropagation();

    scheduleDragUpdate(ctrl);
  }

  function endDrag(e) {
    if (pending) {
      if (e.pointerId == null || e.pointerId === pending.pid) pending = null;
      return;
    }
    if (!drag) return;
    if (e.pointerId != null && e.pointerId !== drag.pid) return;

    try { drag.blockEl && drag.blockEl.releasePointerCapture(drag.pid); } catch (_) {}

    try {
      if (EditorApp.actions?.updateObject) {
        EditorApp.actions.updateObject(drag.objId, { x: drag.nx, y: drag.ny });
      }
    } catch (_) {}

    drag = null;
  }
  
  function hitTestParagraphAt(clientX, clientY) {
  const overlayEl = getOverlayEl();
  if (!overlayEl) return null;

  // Tous les paragraphes visibles sur l’overlay (ordre DOM = z-order)
  const nodes = Array.from(overlayEl.querySelectorAll('[data-type="text_paragraph"]'));
  if (!nodes.length) return null;

  // On prend le dernier qui contient le point (celui “au-dessus” visuellement)
  for (let i = nodes.length - 1; i >= 0; i--) {
    const el = nodes[i];
    const r = el.getBoundingClientRect();
    if (clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom) {
      return el;
    }
  }
  return null;
}

function resolveParagraphBlockFromEvent(e) {
  // 1) normal : target/closest
  let blockEl = findParagraphBlockFromEventTarget(e.target);
  if (blockEl) return blockEl;

  // 2) fallback : hit-test par coordonnées (quand target = pageContainer)
  blockEl = hitTestParagraphAt(e.clientX, e.clientY);
  return blockEl;
}


  function installRoutingOnce() {
    if (R.routingInstalled) return;
    R.routingInstalled = true;


// ✅ GLOBAL: click outside paragraph => hide toolbar (si pas en édition)
document.addEventListener("pointerdown", (e) => {
  const ctrl = ensureController();
  if (!ctrl) return;

  // ignore right/middle click
  if (e.button != null && e.button !== 0) return;

  // ignore click in toolbar
  const tb = ctrl.__toolbarEl;
  if (tb && tb.contains && tb.contains(e.target)) return;

  // ignore popovers
  if (
    e.target?.closest?.('[data-zh-popover="1"]') ||
    e.target?.closest?.(".zh-font-pop") ||
    e.target?.closest?.(".zh-color-pop") ||
    e.target?.closest?.(".zh-cp-pop") ||
    e.target?.closest?.(".tt-color-pop") ||
    e.target?.closest?.(".color-pop") ||
    e.target?.closest?.("[data-color-picker-pop]")
  ) return;

  // ignore click inside a paragraph block (sinon ça clignote)
  const inPara = !!resolveParagraphBlockFromEvent(e);
  if (inPara) return;

  // si édition => ParagraphTools gère déjà outside commit (onOutsidePointerDown)
  const act = ctrl.getActive?.();
  if (act && ctrl.isEditingObject?.(act.objectId)) return;

  // sinon: hide toolbar
  ctrl.clearActive?.();
}, true);



    // dblclick => edit
document.addEventListener("dblclick", (e) => {
  const blockEl = resolveParagraphBlockFromEvent(e);
  console.log("[para_adapter] DBL target =", e.target, " resolvedBlock=", blockEl);
  if (!blockEl) return;

  const ctrl = ensureController();
  if (!ctrl) return;

  const { pageIndex, objId } = getIdsFromBlock(blockEl);
  if (!objId) return;

  try { A.selectObject(objId); } catch (_) { state.selectedObjectId = objId; }
  try { EditorApp.render?.renderOptionsPanel?.(); } catch (_) {}

  try { ctrl.enter(pageIndex, objId, blockEl); } catch (err) {
    console.warn("[para_adapter] ctrl.enter error", err);
  }

  setParagraphEditingVisual(blockEl, true);

  const rich = blockEl.querySelector('[data-role="richtext"]');
  if (rich) {
    requestAnimationFrame(() => {
      try { rich.focus({ preventScroll: true }); } catch (_) { try { rich.focus(); } catch(_){} }
    });
  }

  e.preventDefault();
  e.stopPropagation();
}, true);



  // pointerdown => select (+ drag seulement si hit-layer)
document.addEventListener("pointerdown", (e) => {
  const blockEl = resolveParagraphBlockFromEvent(e);
  if (!blockEl) return;

  const ctrl = ensureController();
  if (!ctrl) return;

  const { pageIndex, objId } = getIdsFromBlock(blockEl);
  if (!objId) return;

  // ✅ only primary button + ignore right/middle click
  if (e.button !== 0) return;

  ensureParagraphHitLayer(blockEl);

  const inRich = isInsideRichtext(e.target);
  const onHit  = isOnHitLayer(e.target);

  // ✅ détecte édition AVANT toute action (l'ancien bug venait du "active=null" après exit)
  const isEditingThis = !!(ctrl.isEditingObject && ctrl.isEditingObject(objId));
  const wantMoveFromText = !!e.altKey;

  // ✅ sélection EditorApp (toujours)
  try { A.selectObject(objId); } catch (_) { state.selectedObjectId = objId; }
  try { EditorApp.render?.renderOptionsPanel?.(); } catch (_) {}

  // -----------------------------------------------------------------------
  // 1) Gestion toolbar / édition (sans "toggle" et sans clignotement)
  // -----------------------------------------------------------------------

  // ✅ A) En édition + clic DANS le texte => on laisse le caret/selection
  // et surtout: on NE fait ni setActive ni exit
  if (isEditingThis && inRich && !wantMoveFromText) {
    try { ctrl.onMoveOrResize?.(); } catch (_) {}
    return;
  }

  // ✅ B) En édition + clic HORS texte :
  // - si on clique sur hit-layer (ou Alt) => on commit pour pouvoir drag
  // - sinon on commit et on garde la toolbar (mode sélection)
  if (isEditingThis && !inRich) {
    try { ctrl.exit?.(true); } catch (_) {}
    setParagraphEditingVisual(blockEl, false);

    // ✅ IMPORTANT: après exit(), le ctrl n'est plus "editing"
    // on remet la toolbar en mode sélection (ça évite disparition/clignote)
    try { ctrl.setActive?.(pageIndex, objId, blockEl); } catch (_) {}
  }

  // ✅ C) Hors édition => clic simple => toolbar visible sous/au-dessus du bloc
  if (!isEditingThis) {
    try {
      if (typeof ctrl.setActive === "function") {
        ctrl.setActive(pageIndex, objId, blockEl);
      } else {
        try { notifyParagraphSelected(ctrl, pageIndex, objId, blockEl); } catch (_) {}
        ctrl.ensureToolbar?.();
        ctrl.onMoveOrResize?.();
      }
    } catch (err) {
      console.warn("[para_adapter] setActive error", err);
    }
  }

  // -----------------------------------------------------------------------
  // 2) Préparation drag
  // -----------------------------------------------------------------------

  // ✅ Hors édition : clic dans le texte (pas hit-layer) => pas de drag
  // (laisse dblclick fonctionner)
  if (!isEditingThis && inRich && !wantMoveFromText && !onHit) return;

  // ✅ Drag seulement si hit-layer (ou Alt+drag depuis le texte)
  if (!onHit && !(wantMoveFromText && inRich)) return;

  const page = state.pages?.[pageIndex];
  const obj = page?.objects?.find(o => String(o.id) === String(objId));
  if (!obj) return;

  pending = {
    pid: e.pointerId,
    pageIndex,
    objId,
    blockEl,
    objRef: obj,
    startX: e.clientX,
    startY: e.clientY,
    lastX: e.clientX,
    lastY: e.clientY,
    ox: Number(obj.x || 0),
    oy: Number(obj.y || 0),
    ctrl
  };
}, true);



    document.addEventListener("pointermove", (e) => {
      if (pending && e.pointerId === pending.pid) {
        pending.lastX = e.clientX;
        pending.lastY = e.clientY;

        const dist = Math.hypot(pending.lastX - pending.startX, pending.lastY - pending.startY);
        if (dist >= DRAG_THRESHOLD_PX) {
          const ctrl = pending.ctrl || ensureController();
          if (!ctrl) return;
          beginDragFromPending(e, ctrl);
        }
        return;
      }

      if (drag && e.pointerId === drag.pid) {
        drag.lastX = e.clientX;
        drag.lastY = e.clientY;

        const ctrl = ensureController();
        if (!ctrl) return;

        scheduleDragUpdate(ctrl);
        e.preventDefault();
      }
    }, true);

    document.addEventListener("pointerup", endDrag, true);
    document.addEventListener("pointercancel", endDrag, true);

    log("routing installed ✅");
  }

  mountOnAfterCanvasRender();
  console.log("[para_adapter] ready");
})(window);
