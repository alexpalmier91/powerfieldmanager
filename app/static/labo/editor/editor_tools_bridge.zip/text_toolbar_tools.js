// app/static/labo/editor/text_toolbar_tools.js
// ------------------------------------------------------------
// Text Toolbar Tools — barre d’outils réutilisable (texte simple, paragraphe, texte cercle/path…)
// Sans dépendances externes.
//
// ✅ Un seul composant toolbar
// ✅ Font picker via window.FontPickerTools (font_picker_tools.js)
// ✅ Taille 4 → 90
// ✅ Couleur via window.ColorPickerTools (color_picker_tools.js) — style "Google"
// ✅ Align (left/center/right), B I U, Transform (none/upper/lower/capitalize)
// ✅ Option cercle : EXT / INT (toggle) si ctx.circleSide présent
// ✅ Color picker s’ouvre sur ctx.anchorRect si fourni (évite de masquer cercle/texte)
//
// FIX sélection couleur:
// ✅ On garde la sélection texte en empêchant le popover couleur de prendre le focus
//    (preventDefault sur pointerdown/mousedown dans le popover, sauf INPUT/TEXTAREA/SELECT)
// ------------------------------------------------------------

(function (global) {
  "use strict";

  // ------------------------------------------------------------
  // Utils
  // ------------------------------------------------------------
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function isInPopover(target) {
    if (!target || !target.closest) return false;
	if (target.closest('[data-zh-popover="1"]')) return true;
    if (target.closest(".zh-font-pop")) return true;
    if (target.closest(".zh-color-pop")) return true;
    if (target.closest(".zh-cp-pop")) return true; // ✅ ton color picker actuel
    if (target.closest(".tt-color-pop")) return true;
    if (target.closest(".color-pop")) return true;
    if (target.closest("[data-color-picker-pop]")) return true;
    return false;
  }

  function ensureCssOnce() {
    if (document.getElementById("tt_toolbar_css")) return;
    const st = document.createElement("style");
    st.id = "tt_toolbar_css";
    st.textContent = `
.tt-toolbar{
  position:absolute;
  z-index:99999;
  display:flex;
  align-items:center;
  gap:10px;
  padding:8px 10px;
  background:#ffffff;
  color:#0f172a;
  border:1px solid rgba(15,23,42,.10);
  border-radius:14px;
  box-shadow:0 10px 30px rgba(2,6,23,.12);
  font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;
  user-select:none;
}
.tt-toolbar[hidden]{display:none;}
.tt-toolbar .tt-group{display:flex;align-items:center;gap:8px;}
.tt-toolbar .tt-sep{width:1px;height:22px;background:rgba(15,23,42,.10);margin:0 2px;}
.tt-toolbar select{
  height:30px;border-radius:12px;border:1px solid rgba(15,23,42,.12);
  background:#fff;color:#0f172a;padding:0 10px;font-size:13px;outline:none;cursor:pointer;
}
.tt-toolbar .tt-iconbtn{
  width:30px;height:30px;border-radius:12px;border:1px solid rgba(15,23,42,.12);
  background:#fff;display:inline-flex;align-items:center;justify-content:center;
  cursor:pointer;font-size:13px;line-height:1;padding:0;
}
.tt-toolbar .tt-iconbtn:hover{background:rgba(15,23,42,.04);}
.tt-toolbar .tt-iconbtn.is-on{background:rgba(37,99,235,.10);border-color:rgba(37,99,235,.35);}
.tt-toolbar .tt-textbtn{
  height:30px;padding:0 10px;border-radius:12px;border:1px solid rgba(15,23,42,.12);
  background:#fff;cursor:pointer;font-size:13px;font-weight:800;
}
.tt-toolbar .tt-textbtn:hover{background:rgba(15,23,42,.04);}
.tt-toolbar .tt-textbtn.is-on{background:rgba(37,99,235,.10);border-color:rgba(37,99,235,.35);}
.tt-toolbar .tt-color-dot{
  width:14px;height:14px;border-radius:6px;border:1px solid rgba(15,23,42,.18);
  background:#111827;
}
    `.trim();
    document.head.appendChild(st);
  }

  // ------------------------------------------------------------
  // Toolbar creation
  // ------------------------------------------------------------
  function createTextToolbar(cfg = {}) {
    ensureCssOnce();

    const hostEl = cfg.hostEl || document.body;
		try {
	  const prev = (hostEl || document.body).querySelector(".tt-toolbar[data-tt-singleton='1']");
	  if (prev) prev.remove();
	} catch (_) {}
    const onAction = (typeof cfg.onAction === "function") ? cfg.onAction : () => {};
    const onBeforeOpenFontPicker =
      (typeof cfg.onBeforeOpenFontPicker === "function") ? cfg.onBeforeOpenFontPicker : null;
    const onBeforeOpenColorPicker =
      (typeof cfg.onBeforeOpenColorPicker === "function") ? cfg.onBeforeOpenColorPicker : null;
    const getContext = (typeof cfg.getContext === "function") ? cfg.getContext : () => ({});

    const tb = document.createElement("div");
    tb.className = "tt-toolbar";
	tb.setAttribute("data-tt-singleton", "1");
    tb.hidden = true;

    tb.addEventListener("pointerdown", (e) => e.stopPropagation(), { capture: true });
    tb.addEventListener("mousedown", (e) => e.stopPropagation(), { capture: true });

    const group = () => { const g = document.createElement("div"); g.className = "tt-group"; return g; };
    const sep   = () => { const s = document.createElement("div"); s.className = "tt-sep"; return s; };

    const iconBtn = (label, title) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "tt-iconbtn";
      b.textContent = label;
      b.title = title || "";
      return b;
    };
    const textBtn = (label, title) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "tt-textbtn";
      b.textContent = label;
      b.title = title || "";
      return b;
    };

    // ----------------------------------------------------------
    // Font picker (FontPickerTools)
    // ----------------------------------------------------------
    const btnFont = iconBtn("Aa", "Police");
    btnFont.style.width = "42px";
    btnFont.style.fontWeight = "900";

    let fontPop = null;

    btnFont.addEventListener("pointerdown", (e) => {
      e.stopPropagation();
      const ctx = getContext() || {};
      try { onBeforeOpenFontPicker && onBeforeOpenFontPicker(ctx); } catch (_) {}
    }, { capture: true });

    btnFont.addEventListener("click", (e) => {
      e.stopPropagation();

      const FP = global.FontPickerTools || null;
      const createFontPickerPopover = FP && FP.createFontPickerPopover;
      if (!createFontPickerPopover) {
        console.warn("[TextToolbar] FontPickerTools manquant: charge font_picker_tools.js avant text_toolbar_tools.js");
        return;
      }

      const ctx = getContext() || {};
      const selectedKey = String(ctx.currentFontKey || ctx.fontKey || "helv").trim();

      if (!fontPop) {
        fontPop = createFontPickerPopover({
          fonts: ctx.fonts || [],
          selected: selectedKey,
          onPick: (fontKey) => onAction({ type: "font", value: fontKey }),
        });
      } else {
        try { fontPop.setFonts && fontPop.setFonts(ctx.fonts || []); } catch (_) {}
        try { fontPop.setSelected && fontPop.setSelected(selectedKey); } catch (_) {}
      }

      requestAnimationFrame(() => {
        if (!fontPop) return;
        const opened = (fontPop.isOpen && fontPop.isOpen()) || false;
        if (opened) fontPop.close && fontPop.close();
        else fontPop.open && fontPop.open(btnFont);
      });
    }, { capture: true });

    // ----------------------------------------------------------
    // Size 4 -> 90
    // ----------------------------------------------------------
    const sizeSel = document.createElement("select");
    const sizeOptions = [];
    for (let i = 4; i <= 90; i++) sizeOptions.push(i);
    sizeSel.innerHTML = sizeOptions.map((n) => `<option value="${n}">${n}</option>`).join("");
    sizeSel.addEventListener("change", () => {
      const v = clamp(Number(sizeSel.value || 14), 4, 90);
      onAction({ type: "size", value: v });
    }, true);

    // ----------------------------------------------------------
    // Color picker (ColorPickerTools)
    // ----------------------------------------------------------
    const btnColor = iconBtn("", "Couleur");
    const dot = document.createElement("span");
    dot.className = "tt-color-dot";
    btnColor.appendChild(dot);

    let colorPop = null;
    let colorWarned = false;

    // --- popover compat helpers --------------------------------
    function getPopEl(pop) {
      if (!pop) return null;
      return pop.el || pop.pop || pop.root || pop.container || pop._el || null;
    }
    function popIsOpen(pop) {
      if (!pop) return false;
      if (typeof pop.isOpen === "function") return !!pop.isOpen();
      const el = getPopEl(pop);
      if (el && el.hidden != null) return !el.hidden;
      if (el && el.style) return el.style.display !== "none";
      return false;
    }
    function popOpen(pop, anchorEl) {
      if (!pop) return;
      if (typeof pop.open === "function") return pop.open(anchorEl);
      if (typeof pop.openAt === "function") {
        const r = anchorEl.getBoundingClientRect();
        return pop.openAt(r.left, r.bottom + 8);
      }
      const el = getPopEl(pop);
      if (el) {
        el.hidden = false;
        const r = anchorEl.getBoundingClientRect();
        el.style.position = "fixed";
        el.style.left = `${Math.round(r.left)}px`;
        el.style.top = `${Math.round(r.bottom + 8)}px`;
      }
    }

    // ✅ NOUVEAU: open sur un rect “safe” (fourni par ctx.anchorRect)
    function popOpenAtRect(pop, rect) {
      if (!pop || !rect) return;
      if (typeof pop.openAt === "function") {
        return pop.openAt(rect.left, rect.bottom + 8);
      }
      const el = getPopEl(pop);
      if (el) {
        el.hidden = false;
        el.style.position = "fixed";
        el.style.left = `${Math.round(rect.left)}px`;
        el.style.top = `${Math.round(rect.bottom + 8)}px`;
      }
    }

    function popClose(pop) {
      if (!pop) return;
      if (typeof pop.close === "function") return pop.close();
      const el = getPopEl(pop);
      if (el) el.hidden = true;
    }
    function popSetColor(pop, c) {
      if (!pop) return;
      if (typeof pop.setColor === "function") return pop.setColor(c, { silent: true });
      if (typeof pop.setInitial === "function") return pop.setInitial(c);
      if (typeof pop.setValue === "function") return pop.setValue(c);
    }

    function ensureColorPop(initial) {
      const CP = global.ColorPickerTools || null;
      const create = CP && (CP.createColorPickerPopover || CP.createColorPopover);
      if (!create) {
        if (!colorWarned) {
          colorWarned = true;
          console.warn("[TextToolbar] ColorPickerTools manquant: charge color_picker_tools.js avant text_toolbar_tools.js");
        }
        return null;
      }

      if (!colorPop) {
        try {
          colorPop = create({
            initial: initial || "#111827",
            storageKey: "zh_color_recent",
            debug: true, // ✅ AJOUT
            onPick: (hex) => {
              console.log("%c[TT] onPick from ColorPicker =>", "color:#2563eb;font-weight:800;", hex);
              onAction({ type: "color", value: hex });
            },
            onClose: () => console.log("%c[TT] color pop closed", "color:#2563eb;font-weight:800;"),
          });
          console.log("%c[TT] colorPop created keys=", "color:#2563eb;font-weight:800;", colorPop && Object.keys(colorPop));
        } catch (e1) {
          try {
            colorPop = create(initial || "#111827", (hex) => onAction({ type: "color", value: hex }));
          } catch (e2) {
            console.warn("[TextToolbar] createColorPickerPopover signature inconnue", e1, e2);
            return null;
          }
        }
      }
      return colorPop;
    }

    // --- KEY FIX: prevent focus steal inside color pop ----------
    let colorPopGuardsInstalled = false;

    function installColorPopGuards(pop) {
      if (colorPopGuardsInstalled) return;
      const el = getPopEl(pop);
      if (!el || !el.addEventListener) return;

      // Empêche la perte de sélection quand on clique sur une pastille.
      // On laisse les INPUT/TEXTAREA/SELECT vivre (sinon on ne peut pas taper un hex).
      const shouldAllowFocus = (t) => {
        if (!t) return false;
        const tag = (t.tagName || "").toLowerCase();
        if (tag === "input" || tag === "textarea" || tag === "select") return true;
        if (t.isContentEditable) return true;
        return false;
      };

      const guardDown = (e) => {
		  const t = e.target;
		  if (shouldAllowFocus(t)) return; // input/textarea/select ok

		  // ✅ on empêche le focus de partir, MAIS on laisse l'event continuer
		  // pour que le color picker reçoive bien le pointerdown (drag SV, etc.)
		  try { e.preventDefault(); } catch (_) {}

		  // ❌ surtout pas de stopPropagation ici
		  // e.stopPropagation();
		};


      // capture = true => avant que le navigateur ne bascule le focus
      el.addEventListener("pointerdown", guardDown, true);
      el.addEventListener("mousedown", guardDown, true);

      colorPopGuardsInstalled = true;
    }

    // Sauve la sélection AVANT blur (double safety)
    btnColor.addEventListener("pointerdown", (e) => {
      try { e.preventDefault(); } catch (_) {}
      e.stopPropagation();

      const ctx = getContext() || {};
      try { onBeforeOpenColorPicker && onBeforeOpenColorPicker(ctx); } catch (_) {}
    }, { capture: true });

    btnColor.addEventListener("click", (e) => {
      e.stopPropagation();

      const ctx = getContext() || {};
      const initial = ctx.color || "#111827";

      const pop = ensureColorPop(initial);
      if (!pop) return;

      // sync sans déclencher onPick
      try { popSetColor(pop, initial); } catch (_) {}

      requestAnimationFrame(() => {
        const opened = popIsOpen(pop);
        if (opened) {
          popClose(pop);
        } else {
          // ✅ si ctx.anchorRect existe (ex: texte cercle), ouvre le picker là (évite de masquer cercle/texte)
          if (ctx.anchorRect) popOpenAtRect(pop, ctx.anchorRect);
          else popOpen(pop, btnColor);

          // ✅ après ouverture : installe guards anti-perte de sélection
          try { installColorPopGuards(pop); } catch (_) {}
        }
      });
    }, { capture: true });

    // ----------------------------------------------------------
    // Align
    // ----------------------------------------------------------
    const btnLeft = iconBtn("≡", "Align gauche");
    const btnCenter = iconBtn("≣", "Align centre");
    const btnRight = iconBtn("≡", "Align droite");
    btnLeft.style.justifyContent = "flex-start"; btnLeft.style.paddingLeft = "8px";
    btnCenter.style.justifyContent = "center";
    btnRight.style.justifyContent = "flex-end"; btnRight.style.paddingRight = "8px";

    btnLeft.addEventListener("click", () => onAction({ type: "align", value: "left" }), true);
    btnCenter.addEventListener("click", () => onAction({ type: "align", value: "center" }), true);
    btnRight.addEventListener("click", () => onAction({ type: "align", value: "right" }), true);

    // ----------------------------------------------------------
    // ✅ Circle side toggle (outer / inner)
    // (affiché uniquement si ctx.circleSide est fourni)
    // ----------------------------------------------------------
    const btnOuter = textBtn("EXT", "Texte à l'extérieur du cercle");
    const btnInner = textBtn("INT", "Texte à l'intérieur du cercle");
    btnOuter.style.fontWeight = "900";
    btnInner.style.fontWeight = "900";

    btnOuter.addEventListener("click", () => onAction({ type: "circleSide", value: "outer" }), true);
    btnInner.addEventListener("click", () => onAction({ type: "circleSide", value: "inner" }), true);

    // ----------------------------------------------------------
    // B I U
    // ----------------------------------------------------------
    const btnB = textBtn("B", "Gras"); btnB.style.fontWeight = "900";
    const btnI = textBtn("I", "Italique"); btnI.style.fontStyle = "italic";
    const btnU = textBtn("U", "Souligné"); btnU.style.textDecoration = "underline";

    btnB.addEventListener("click", () => onAction({ type: "bold" }), true);
    btnI.addEventListener("click", () => onAction({ type: "italic" }), true);
    btnU.addEventListener("click", () => onAction({ type: "underline" }), true);

    // ----------------------------------------------------------
    // Transform
    // ----------------------------------------------------------
    const trSel = document.createElement("select");
    trSel.innerHTML = `
      <option value="none">Aa</option>
      <option value="upper">MAJ</option>
      <option value="lower">min</option>
      <option value="capitalize">Cap</option>
    `.trim();
    trSel.addEventListener("change", () => {
      onAction({ type: "transform", value: String(trSel.value || "none") });
    }, true);

    // ----------------------------------------------------------
    // Assemble
    // ----------------------------------------------------------
    const g1 = group(); g1.appendChild(btnFont);
    const g2 = group(); g2.appendChild(sizeSel);
    const g3 = group(); g3.appendChild(btnColor);
    const g4 = group(); g4.appendChild(btnLeft); g4.appendChild(btnCenter); g4.appendChild(btnRight);

    const g4b = group(); // ✅ side toggle group
    g4b.appendChild(btnOuter);
    g4b.appendChild(btnInner);

    const g5 = group(); g5.appendChild(btnB); g5.appendChild(btnI); g5.appendChild(btnU);
    const g6 = group(); g6.appendChild(trSel);

    tb.appendChild(g1);
    tb.appendChild(g2);
    tb.appendChild(sep());
    tb.appendChild(g3);
    tb.appendChild(sep());
    tb.appendChild(g4);
    tb.appendChild(sep());
    tb.appendChild(g4b);
    tb.appendChild(sep());
    tb.appendChild(g5);
    tb.appendChild(sep());
    tb.appendChild(g6);

    tb._refs = {
      btnFont, sizeSel, btnColor, dot,
      btnLeft, btnCenter, btnRight,
      btnOuter, btnInner, g4b,
      btnB, btnI, btnU, trSel
    };

    (hostEl || document.body).appendChild(tb);

    // ----------------------------------------------------------
    // Outside click => close popovers
    // ----------------------------------------------------------
    const onDocDown = (e) => {
      if (isInPopover(e.target)) return;
      if (tb.contains(e.target)) return;
      try { colorPop && (colorPop.close ? colorPop.close() : popClose(colorPop)); } catch (_) {}
      try { fontPop && fontPop.close && fontPop.close(); } catch (_) {}
    };
    document.addEventListener("pointerdown", onDocDown, true);

    function show() { tb.hidden = false; }
    function hide() { tb.hidden = true; }

    function setValues(state) {
      const r = tb._refs;
      if (!r) return;

      const sz = clamp(Math.round(Number(state.size || 14)), 4, 90);
      if (r.sizeSel) r.sizeSel.value = String(sz);

      const c = state.color || "#111827";
      if (r.dot) r.dot.style.background = (c === "transparent") ? "transparent" : c;

      if (r.btnLeft) r.btnLeft.classList.toggle("is-on", state.align === "left");
      if (r.btnCenter) r.btnCenter.classList.toggle("is-on", state.align === "center");
      if (r.btnRight) r.btnRight.classList.toggle("is-on", state.align === "right");

      if (r.btnB) r.btnB.classList.toggle("is-on", !!state.bold);
      if (r.btnI) r.btnI.classList.toggle("is-on", !!state.italic);
      if (r.btnU) r.btnU.classList.toggle("is-on", !!state.underline);

      if (r.trSel) r.trSel.value = String(state.transform || "none");

      if (r.btnFont) {
        const k = String(state.fontKey || "helv").trim();
        const label = k === "helv" ? "Helvetica (défaut)" : k.split(",")[0].trim();
        r.btnFont.title = `Police: ${label}`;
      }

      // ✅ Toggle Ext/Int : affiché seulement si ctx.circleSide est fourni
      if (r.g4b) {
        const hasSide = (state.circleSide === "outer" || state.circleSide === "inner");
        r.g4b.style.display = hasSide ? "" : "none";

        if (hasSide) {
          if (r.btnOuter) r.btnOuter.classList.toggle("is-on", state.circleSide === "outer");
          if (r.btnInner) r.btnInner.classList.toggle("is-on", state.circleSide === "inner");
        }
      }
    }

  function positionUnderRect(objRect, hostRect) {
  if (!objRect) return;

  const hostR = hostRect || (hostEl && hostEl.getBoundingClientRect ? hostEl.getBoundingClientRect() : null);

  const pad = 8;
  const tbW = tb.offsetWidth || 360;
  const tbH = tb.offsetHeight || 44;

  // position "préférée" = sous l’objet
  const baseLeft = objRect.left + (objRect.width / 2) - (tbW / 2);
  const belowTop = objRect.bottom + 10;
  const aboveTop = objRect.top - 10 - tbH;

  if (hostR) {
    // coords relatives au host
    let left = baseLeft - hostR.left;

    // ✅ Flip vertical si trop bas
    const belowRel = belowTop - hostR.top;
    const aboveRel = aboveTop - hostR.top;

    const maxLeft = hostR.width - tbW - pad;

    // clamp X
    left = clamp(left, pad, Math.max(pad, maxLeft));

    // choisir Y
    const maxTop = hostR.height - tbH - pad;
    let top = belowRel;

    // si en bas ça déborde -> tenter au-dessus
    if (top > maxTop) top = aboveRel;

    // clamp Y final
    top = clamp(top, pad, Math.max(pad, maxTop));

    tb.style.left = `${left}px`;
    tb.style.top  = `${top}px`;
    return;
  }

  // fallback viewport
  let left = clamp(baseLeft, pad, window.innerWidth - tbW - pad);
  let top  = belowTop;

  if (top + tbH + pad > window.innerHeight) top = aboveTop;
  top = clamp(top, pad, window.innerHeight - tbH - pad);

  tb.style.left = `${left}px`;
  tb.style.top  = `${top}px`;
}


    function updateFromContext() {
      const ctx = getContext() || {};
      if (!ctx.isVisible) { hide(); return; }
      show();
      setValues(ctx);
      if (ctx.anchorRect) positionUnderRect(ctx.anchorRect, ctx.hostRect || null);
    }

    function destroy() {
      document.removeEventListener("pointerdown", onDocDown, true);
      try { colorPop && colorPop.destroy && colorPop.destroy(); } catch (_) {}
      try { fontPop && fontPop.destroy && fontPop.destroy(); } catch (_) {}
      try { tb.remove(); } catch (_) {}

      colorPop = null;
      fontPop = null;
      colorPopGuardsInstalled = false;
    }

    return {
      el: tb,
      updateFromContext,
      show,
      hide,
      setValues,
      positionUnderRect,
      destroy,
      closePopovers: () => {
        try { colorPop && (colorPop.close ? colorPop.close() : popClose(colorPop)); } catch (_) {}
        try { fontPop && fontPop.close && fontPop.close(); } catch (_) {}
      },
      _getFontPop: () => fontPop,
      _getColorPop: () => colorPop,
    };
  }

  // ------------------------------------------------------------
  // Export / Global bridge
  // ------------------------------------------------------------
  try {
    global.TextToolbarTools = global.TextToolbarTools || {};
    global.TextToolbarTools.createTextToolbar = createTextToolbar;
  } catch (_) {}

  try { console.log("[TT] text_toolbar_tools.js loaded v=COLOR-SELECTION-FIX+SIDE+ANCHORRECT"); } catch(_) {}

})(window);
